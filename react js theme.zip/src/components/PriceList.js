import React from 'react';

const PriceList = (props) =>{
    const pricelist=[
       {
        id:1,
        name:"Hair Cutting",
        price:"200"
       } ,
       {
        id:1,
        name:"Hair Spa",
        price:"600"
       }
    ]
}